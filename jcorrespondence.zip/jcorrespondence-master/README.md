# jcorrespondence
This is a Component and a Plugin for Joomla! 3.6.2. With this component Administrators &amp; Super Users may contact by sending messages to each other. 
